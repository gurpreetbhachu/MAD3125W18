package com.example.macstudent.thunder_day1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{
    Button btnLogin;
    Button btnRegister;
    EditText txtUsername;
    EditText txtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        txtUsername = (EditText) findViewById(R.id.etxtUsername);
        txtPassword = (EditText) findViewById(R.id.etxtPassword);

    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnLogin.getId())
        {
            String user = txtUsername.getText().toString();
            String pass = txtPassword.getText().toString();

            Toast.makeText(this,user +" "+ pass ,Toast.LENGTH_LONG).show();
        }
        else if(view.getId() == btnRegister.getId())
        {
            Toast.makeText(this,"Register Tapped !!",Toast.LENGTH_LONG).show();
        }
    }
}
